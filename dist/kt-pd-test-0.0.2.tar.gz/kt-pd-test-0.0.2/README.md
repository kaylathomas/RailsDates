# PyDate

This is a library is an almost one-to-one conversion of Ruby on Rails' useful date helper methods for use in Python libraries.

For now, while it's meant to not be announced publicly, it's simply aliased as "pd-test".